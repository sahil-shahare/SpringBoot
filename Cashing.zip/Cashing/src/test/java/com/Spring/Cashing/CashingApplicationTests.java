package com.Spring.Cashing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CashingApplicationTests {

	@Test
	void contextLoads() {
	}

}
